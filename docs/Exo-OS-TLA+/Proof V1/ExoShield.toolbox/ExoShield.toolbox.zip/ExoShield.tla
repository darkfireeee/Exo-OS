--------------------------- MODULE ExoShield ---------------------------
EXTENDS Integers, Sequences, FiniteSets, TLC

THREADS == {"T1", "T2"}
AUTHORIZED_GRAPH == {<<"Net", "Vfs">>, <<"Vfs", "Crypto">>}
EMPTY_ENTRY == "EMPTY"

VARIABLES
    WatchdogMissed,
    HandoffFlag,
    LedgerP0Entries,
    ControlFlowViolations,
    IommuNicWhitelist,
    NicDmaRequests,
    IpcMessages

vars == <<WatchdogMissed, HandoffFlag, LedgerP0Entries, ControlFlowViolations,
          IommuNicWhitelist, NicDmaRequests, IpcMessages>>

--------------------------------------------------------------
\* INITIALIZATION
--------------------------------------------------------------
Init ==
    /\ WatchdogMissed = 0
    /\ HandoffFlag = 0
    /\ LedgerP0Entries = << >>
    /\ ControlFlowViolations = {}
    /\ IommuNicWhitelist = { "0xAAAA", "0xBBBB" }  
    /\ NicDmaRequests = {}
    /\ IpcMessages = {}

--------------------------------------------------------------
\* ADVERSARIAL & SYSTEM ACTIONS
--------------------------------------------------------------
TickWatchdog ==
    /\ HandoffFlag = 0
    /\ WatchdogMissed' = WatchdogMissed + 1
    /\ HandoffFlag' = IF WatchdogMissed' >= 3 THEN 1 ELSE 0
    /\ UNCHANGED <<LedgerP0Entries, ControlFlowViolations, IommuNicWhitelist, NicDmaRequests, IpcMessages>>

PingWatchdog ==
    /\ HandoffFlag = 0
    /\ WatchdogMissed' = 0
    /\ UNCHANGED <<HandoffFlag, LedgerP0Entries, ControlFlowViolations, IommuNicWhitelist, NicDmaRequests, IpcMessages>>

TriggerCp(t) ==
    /\ HandoffFlag = 0
    /\ ControlFlowViolations' = ControlFlowViolations \cup {t}
    /\ HandoffFlag' = 1  
    /\ LedgerP0Entries' = Append(LedgerP0Entries, "CpViolation")
    /\ UNCHANGED <<WatchdogMissed, IommuNicWhitelist, NicDmaRequests, IpcMessages>>

RequestDma(addr) ==
    /\ HandoffFlag = 0
    /\ NicDmaRequests' = NicDmaRequests \cup {[target_addr |-> addr, status |-> IF addr \in IommuNicWhitelist THEN "OK" ELSE "IOMMU_FAULT"]}
    /\ UNCHANGED <<WatchdogMissed, HandoffFlag, LedgerP0Entries, ControlFlowViolations, IommuNicWhitelist, IpcMessages>>

SendIpc(src, dst) ==
    /\ HandoffFlag = 0
    /\ IpcMessages' = IpcMessages \cup {[src |-> src, dst |-> dst, status |-> IF <<src, dst>> \in AUTHORIZED_GRAPH THEN "ALLOWED" ELSE "REJECTED"]}
    /\ UNCHANGED <<WatchdogMissed, HandoffFlag, LedgerP0Entries, ControlFlowViolations, IommuNicWhitelist, NicDmaRequests>>

\* THE FIX: Allow the system to gracefully idle once the hypervisor takes over
PhoenixFreeze ==
    /\ HandoffFlag = 1
    /\ UNCHANGED vars

Next ==
    \/ TickWatchdog
    \/ PingWatchdog
    \/ \E t \in THREADS : TriggerCp(t)
    \/ \E addr \in {"0xAAAA", "0xCCCC"} : RequestDma(addr)
    \/ \E src \in {"Net", "Vfs", "Crypto"}, dst \in {"Net", "Vfs", "Crypto"} : SendIpc(src, dst)
    \/ PhoenixFreeze

Spec == Init /\ [][Next]_vars

--------------------------------------------------------------
\* SAFETY PROPERTIES & INVARIANTS
--------------------------------------------------------------
S33_CordonEnforced ==
    \A msg \in IpcMessages :
        (<<msg.src, msg.dst>> \notin AUTHORIZED_GRAPH) => (msg.status = "REJECTED")

S36_NmiThreeStrikes ==
    WatchdogMissed >= 3 => HandoffFlag = 1

S38_CpHandlerImmediate ==
    ControlFlowViolations /= {} => HandoffFlag = 1

S39_NicWhitelistImmutable ==
    [][IommuNicWhitelist' = IommuNicWhitelist]_vars

S40_NicExfiltrationImpossible ==
    \A dma \in NicDmaRequests :
        (dma.target_addr \notin IommuNicWhitelist) => (dma.status = "IOMMU_FAULT")

=============================================================================
